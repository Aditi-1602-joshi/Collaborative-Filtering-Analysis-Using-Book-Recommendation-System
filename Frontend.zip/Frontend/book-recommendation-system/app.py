


from flask import Flask, render_template,request
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load your DataFrame
popular_df = pd.read_pickle('popular.pkl')  # Ensure correct path
books_with_genre = pd.read_pickle('books_with_genre.pkl')
cosine_similarity_score = pd.read_pickle('cosine_similarity_score.pkl')
pt = pd.read_pickle('pt.pkl')

@app.route('/')
def home():
    # Convert popular_df to a dictionary for rendering
    popular_books = popular_df.to_dict(orient='records')
    return render_template('index.html', popular_df=popular_books)



def recommend_by_genre(genre_name, n=10):
    # Ensure that books_with_genre is properly loaded
    genre_books = books_with_genre[books_with_genre['Genre'] == genre_name]
    # Getting the top books based on genre
    top_indices = genre_books.index[:n]

    recommended_books = []

    # Collect the book details for each recommended book
    for idx in top_indices:
        book = {
            'Book-Title': books_with_genre.loc[idx, 'Book-Title'],
            'Book-Author': books_with_genre.loc[idx, 'Book-Author'],
            'Genre': books_with_genre.loc[idx, 'Genre'],
            'Summary': books_with_genre.loc[idx, 'Summary'],
            'Image-URL-M': books_with_genre.loc[idx, 'Image-URL-M']
        }
        recommended_books.append(book)

    return recommended_books


@app.route('/genre', methods=['GET', 'POST'])
def genre_recommendation():
    if request.method == 'POST':
        genre_name = request.form.get('genre_name')
        recommended_books = recommend_by_genre(genre_name, n=10)  # Adjust `n` as needed
        return render_template('genrereco.html', books=recommended_books, genre_name=genre_name)
    return render_template('genrereco.html', books=[], genre_name=None)


def recommend_cosine(book_name):
    # Getting the index of the book name
    index = np.where(pt.index == book_name)[0][0]

    # Getting similar books based on cosine similarity score
    similar_books = sorted(list(enumerate(cosine_similarity_score[index])), key=lambda x: x[1], reverse=True)[
                    1:11]  # Top 5 books, excluding itself

    recommended_books = []
    for i in similar_books:
        book_details = {}

        # Get book details using the index
        temp_df = books_with_genre[books_with_genre['Book-Title'] == pt.index[i[0]]]

        # Store necessary details in the dictionary
        book_details['Book-Title'] = temp_df['Book-Title'].values[0]
        book_details['Book-Author'] = temp_df['Book-Author'].values[0]
        book_details['Image-URL-M'] = temp_df['Image-URL-M'].values[0]
        book_details['Genre'] = temp_df['Genre'].values[0]
        book_details['Summary'] = temp_df['Summary'].values[0]

        # Add the dictionary to the recommended_books list
        recommended_books.append(book_details)

    return recommended_books


@app.route('/title', methods=['GET', 'POST'])
def recommend_by_title_route():
    if request.method == 'POST':
        book_name = request.form['book_name']
        recommendations = recommend_cosine(book_name)  # Call the function
        return render_template('bookreco.html', recommendations=recommendations)
    return render_template('bookreco.html')



if __name__ == "__main__":
    app.run(debug=True)


